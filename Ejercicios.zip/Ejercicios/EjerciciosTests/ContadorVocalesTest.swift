//
//  ContadorVocalesTest.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/17/24.
//

import XCTest

final class ContadorVocalesTest: XCTestCase {
    
    func testContarVocales() {
        let contador = ContadorVocales()
        
        // Prueba: Contar vocales en una cadena
        let resultado1 = contador.contarVocales(cadena: "hola mundo")
        XCTAssertEqual(resultado1, 4, "La cadena 'hola mundo' debería tener 4 vocales")
        
        // Prueba: Contar vocales en una cadena sin vocales
        let resultado2 = contador.contarVocales(cadena: "bcdfghjkl")
        XCTAssertEqual(resultado2, 0, "La cadena 'bcdfghjkl' debería tener 0 vocales")
    }
}
