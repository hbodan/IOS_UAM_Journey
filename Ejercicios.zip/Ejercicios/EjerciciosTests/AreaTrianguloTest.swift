//
//  AreaTrianguloTest.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/17/24.
//

import XCTest

final class AreaTrianguloTest: XCTestCase {
    
    func testCalcularArea() {
        let areaTriangulo = AreaTriangulo()
        
        // Prueba 1: Caso normal
        let resultado1 = areaTriangulo.calcularArea(base: 10, altura: 5)
        XCTAssertEqual(resultado1, 25.0, "El área del triángulo debería ser 25.0")
        
        // Prueba 2: Base y altura cero
        let resultado2 = areaTriangulo.calcularArea(base: 0, altura: 5)
        XCTAssertEqual(resultado2, 0.0, "El área del triángulo debería ser 0.0 cuando la base es 0")
        
        // Prueba 3: Base cero y altura cero
        let resultado3 = areaTriangulo.calcularArea(base: 0, altura: 0)
        XCTAssertEqual(resultado3, 0.0, "El área del triángulo debería ser 0.0 cuando la base y la altura son 0")
        
        // Prueba 4: Base negativa
        let resultado4 = areaTriangulo.calcularArea(base: -5, altura: 10)
        XCTAssertEqual(resultado4, -25.0, "El área del triángulo debería ser -25.0 cuando la base es negativa")
        
        // Prueba 5: Altura negativa
        let resultado5 = areaTriangulo.calcularArea(base: 5, altura: -10)
        XCTAssertEqual(resultado5, -25.0, "El área del triángulo debería ser -25.0 cuando la altura es negativa")
    }
}
