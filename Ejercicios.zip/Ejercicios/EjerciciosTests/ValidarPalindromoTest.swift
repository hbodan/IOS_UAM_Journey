//
//  ValidarPalindromoTest.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/17/24.
//

import XCTest

final class ValidarPalindromoTest: XCTestCase {
    
    func testPalabrasPalindromas() {
        let validador = ValidarPalindromo()
        
        // Prueba: Palabras que son palíndromos
        XCTAssertTrue(validador.esPalindromo(cadena: "Reconocer"), "Reconocer debería ser un palíndromo")
        XCTAssertTrue(validador.esPalindromo(cadena: "Anilina"), "Anilina debería ser un palíndromo")
        XCTAssertTrue(validador.esPalindromo(cadena: "Radar"), "Radar debería ser un palíndromo")
    }
    
    func testFrasesPalindromas() {
        let validador = ValidarPalindromo()
        
        // Prueba: Frases que son palíndromos
        XCTAssertTrue(validador.esPalindromo(cadena: "Anita lava la tina"), "Anita lava la tina debería ser un palíndromo")
        XCTAssertTrue(validador.esPalindromo(cadena: "Romani se conoce sin oro, ni se conoce sin amor"), "Romani se conoce sin oro, ni se conoce sin amor debería ser un palíndromo")
    }
    
    func testNoPalindromos() {
        let validador = ValidarPalindromo()
        
        // Prueba: Cadenas que no son palíndromos
        XCTAssertFalse(validador.esPalindromo(cadena: "Hola"), "Hola no debería ser un palíndromo")
        XCTAssertFalse(validador.esPalindromo(cadena: "Swift"), "Swift no debería ser un palíndromo")
        XCTAssertFalse(validador.esPalindromo(cadena: "Palindromo"), "Palindromo no debería ser un palíndromo")
    }
}
