//
//  VerificarNumeroParTest.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/17/24.
//

import XCTest

final class VerificarNumeroParTest: XCTestCase {
    
    func testNumeroPar() {
        let verificador = VerificarNumeroPar()
        
        // Prueba: Caso de número par
        let resultado1 = verificador.esPar(numero: 4)
        XCTAssertTrue(resultado1, "4 debería ser un número par")
        
        let resultado2 = verificador.esPar(numero: -2)
        XCTAssertTrue(resultado2, "-2 debería ser un número par")
        
        let resultado3 = verificador.esPar(numero: 0)
        XCTAssertTrue(resultado3, "0 debería ser un número par")
    }
    
    func testNumeroImpar() {
        let verificador = VerificarNumeroPar()
        
        // Prueba: Caso de número impar
        let resultado1 = verificador.esPar(numero: 3)
        XCTAssertFalse(resultado1, "3 debería ser un número impar")
        
        let resultado2 = verificador.esPar(numero: -5)
        XCTAssertFalse(resultado2, "-5 debería ser un número impar")
        
        let resultado3 = verificador.esPar(numero: 1)
        XCTAssertFalse(resultado3, "1 debería ser un número impar")
    }
}
