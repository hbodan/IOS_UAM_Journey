//
//  CalculoPotenciaTest.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/16/24.
//

import XCTest

final class CalculoPotenciaTest: XCTestCase {
    
    func testCalcularPotencia() {
        let calculoPotencia = CalculoPotencia()
        
        // Prueba 1: Potencia positiva
        let resultado1 = calculoPotencia.calcularPotencia(base: 2, exponente: 3)
        XCTAssertEqual(resultado1, 8.0, "2 elevado a la 3 debería ser 8.0")
        
        // Prueba 2: Potencia negativa
        let resultado2 = calculoPotencia.calcularPotencia(base: 2, exponente: -2)
        XCTAssertEqual(resultado2, 0.25, "2 elevado a la -2 debería ser 0.25")
        
        // Prueba 3: Base negativa
        let resultado3 = calculoPotencia.calcularPotencia(base: -3, exponente: 3)
        XCTAssertEqual(resultado3, -27.0, "(-3) elevado a la 3 debería ser -27.0")
        
        // Prueba 4: Base cero
        let resultado4 = calculoPotencia.calcularPotencia(base: 0, exponente: 5)
        XCTAssertEqual(resultado4, 0.0, "0 elevado a la 5 debería ser 0.0")
    }
    
    func testPotenciaCero() {
        let calculoPotencia = CalculoPotencia()
        
        // Prueba: Cualquier número elevado a la 0 es 1
        let resultado1 = calculoPotencia.calcularPotencia(base: 5, exponente: 0)
        XCTAssertEqual(resultado1, 1.0, "5 elevado a la 0 debería ser 1.0")
        
        let resultado2 = calculoPotencia.calcularPotencia(base: -10, exponente: 0)
        XCTAssertEqual(resultado2, 1.0, "(-10) elevado a la 0 debería ser 1.0")
        
        let resultado3 = calculoPotencia.calcularPotencia(base: 0, exponente: 0)
        XCTAssertEqual(resultado3, 1.0, "0 elevado a la 0 debería ser 1.0 (definición matemática)")
    }
}
