//
//  ValidarPalindromo.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/17/24.
//

import Foundation

class ValidarPalindromo {
    func esPalindromo(cadena: String) -> Bool {
        let caracteresValidos = cadena.lowercased().filter { $0.isLetter }
        return caracteresValidos == String(caracteresValidos.reversed())
    }
}
