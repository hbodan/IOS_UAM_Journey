//
//  VerificarNumeroPar.swift
//  Ejercicios
//
//  Created by User-UAM on 10/17/24.
//

import Foundation

class VerificarNumeroPar {
    func esPar(numero: Int) -> Bool {
        return numero % 2 == 0
    }
}
