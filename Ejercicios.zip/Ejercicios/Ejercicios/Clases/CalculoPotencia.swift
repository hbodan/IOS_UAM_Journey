//
//  CalculoPotencia.swift
//  EjerciciosTests
//
//  Created by User-UAM on 10/16/24.
//

import Foundation

class CalculoPotencia{
    func calcularPotencia(base: Double, exponente: Int) -> Double{
        return pow(base, Double(exponente))
    }
}
