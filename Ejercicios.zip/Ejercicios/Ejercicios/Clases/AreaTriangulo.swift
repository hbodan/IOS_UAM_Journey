//
//  AreaTriangulo.swift
//  Ejercicios
//
//  Created by User-UAM on 10/17/24.
//

import Foundation

class AreaTriangulo {
    func calcularArea(base: Double, altura: Double) -> Double {
        return (base * altura) / 2
    }
}
